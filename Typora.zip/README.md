#### 原文链接
[链接](https://zhuanlan.zhihu.com/p/648915268?utm_id=0)

#### 破解方法
typora安装后，将下载的app.asar.txt文件中的后缀.txt去掉，并拷贝到typora安装路径下替换。
我的路径是：D:\Typora\resources 根据自己的安装路径进行替换。
输入序列号激活
1. 打开 typora ，点击“输入序列号”：
2. 邮箱一栏中任意填写（但须保证邮箱地址格式正确），输入序列号(在key.txt文件中，任选一条)，点击“激活”。
3. 出现已激活即可